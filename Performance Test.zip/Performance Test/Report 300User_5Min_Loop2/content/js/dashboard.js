/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 88.13425925925925, "KoPercent": 11.86574074074074};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.20761574074074074, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.15166666666666667, 500, 1500, "[POST] Sign In"], "isController": false}, {"data": [0.0, 500, 1500, "[POST] Generate QR"], "isController": false}, {"data": [0.2775, 500, 1500, "[GET] Detail QRIS"], "isController": false}, {"data": [0.19083333333333333, 500, 1500, "[POST] Transfer Intrabank"], "isController": false}, {"data": [0.0, 500, 1500, "[POST] Generate Token Withdraw"], "isController": false}, {"data": [0.4266666666666667, 500, 1500, "[GET] Mutation Detail"], "isController": false}, {"data": [0.0, 500, 1500, "[POST] Generate Token Topup"], "isController": false}, {"data": [0.0, 500, 1500, "[POST] Demo Topup"], "isController": false}, {"data": [0.21, 500, 1500, "[POST] Generate QRIS CPM Transaksi"], "isController": false}, {"data": [0.22416666666666665, 500, 1500, "[POST] Demo QRIS CPM"], "isController": false}, {"data": [0.005, 500, 1500, "[GET] Get Token Transaction History"], "isController": false}, {"data": [0.36916666666666664, 500, 1500, "[GET] Account Mutation Summary"], "isController": false}, {"data": [0.20333333333333334, 500, 1500, "[POST] Transfer QRIS"], "isController": false}, {"data": [0.25416666666666665, 500, 1500, "[GET] List Transfer Destination"], "isController": false}, {"data": [0.37833333333333335, 500, 1500, "[POST] Forgot Username (Email)"], "isController": false}, {"data": [0.17416666666666666, 500, 1500, "[POST] Script Get QR-0"], "isController": false}, {"data": [0.30916666666666665, 500, 1500, "[POST] Script Get QR-1"], "isController": false}, {"data": [0.45416666666666666, 500, 1500, "[GET] User Profile"], "isController": false}, {"data": [0.155, 500, 1500, "[POST] Resend Verification OTP"], "isController": false}, {"data": [0.24583333333333332, 500, 1500, "[POST] Generate QRIS MPM Transaksi"], "isController": false}, {"data": [0.125, 500, 1500, "[POST] Verifikasi OTP"], "isController": false}, {"data": [0.19, 500, 1500, "[POST] Forgot Password"], "isController": false}, {"data": [0.255, 500, 1500, "[POST] Login with PIN"], "isController": false}, {"data": [0.33, 500, 1500, "[GET] Account Mutation Credit"], "isController": false}, {"data": [0.0, 500, 1500, "[POST] Demo Withdraw"], "isController": false}, {"data": [0.31916666666666665, 500, 1500, "[GET] Account Mutation Debit"], "isController": false}, {"data": [0.3575, 500, 1500, "[POST] Forgot Username (Phone)"], "isController": false}, {"data": [0.25833333333333336, 500, 1500, "[POST] Add Transfer Destination"], "isController": false}, {"data": [0.08583333333333333, 500, 1500, "[POST] Verifikasi OTP Forgot Password"], "isController": false}, {"data": [0.2525, 500, 1500, "[GET] Destination Detail"], "isController": false}, {"data": [0.4058333333333333, 500, 1500, "[GET] Account Detail"], "isController": false}, {"data": [0.24833333333333332, 500, 1500, "[PATCH] Add to Favorites"], "isController": false}, {"data": [0.23916666666666667, 500, 1500, "[POST] Logout"], "isController": false}, {"data": [0.0675, 500, 1500, "[POST] Script Get QR"], "isController": false}, {"data": [0.27666666666666667, 500, 1500, "[POST] Change User Profile"], "isController": false}, {"data": [0.034166666666666665, 500, 1500, "[POST] Script Get QRIS-CPM"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 21600, 2563, 11.86574074074074, 13793.553750000021, 66, 200946, 4497.5, 49885.10000000003, 88874.75, 101147.99, 14.329831591307896, 26.59959505061051, 16.67044201684087], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["[POST] Sign In", 600, 3, 0.5, 4044.086666666673, 146, 29920, 3184.5, 8430.5, 10263.749999999995, 14585.170000000002, 0.5726294572045375, 0.826507299415059, 0.14036132202962784], "isController": false}, {"data": ["[POST] Generate QR", 600, 87, 14.5, 33234.7066666667, 2031, 179611, 22092.5, 100387.4, 101123.0, 108247.73000000004, 0.5268713151937393, 2.1608669980321356, 0.2391964899613452], "isController": false}, {"data": ["[GET] Detail QRIS", 600, 3, 0.5, 3990.953333333329, 73, 26717, 2695.0, 9418.199999999999, 13505.149999999985, 19724.590000000004, 0.5709473443811645, 0.5809287008687916, 0.32449491232389843], "isController": false}, {"data": ["[POST] Transfer Intrabank", 600, 4, 0.6666666666666666, 5733.086666666671, 73, 36242, 4296.5, 13335.699999999999, 16502.899999999994, 24502.390000000003, 0.5709239833746936, 0.7237688083769772, 0.3461254526356705], "isController": false}, {"data": ["[POST] Generate Token Withdraw", 600, 205, 34.166666666666664, 60617.86666666664, 1975, 148654, 67240.0, 101114.9, 101146.8, 103418.53, 0.49586694898024963, 0.28063292973895915, 0.2509349868326664], "isController": false}, {"data": ["[GET] Mutation Detail", 600, 3, 0.5, 3030.1816666666664, 72, 23250, 1329.5, 8779.499999999995, 11326.149999999998, 17499.27, 0.5705331061343719, 0.586223695155128, 0.23835636276349123], "isController": false}, {"data": ["[POST] Generate Token Topup", 600, 259, 43.166666666666664, 64227.481666666674, 417, 122424, 73875.5, 101134.8, 101700.9, 102706.65000000001, 0.44520690248781614, 0.24241820181117585, 0.215063773801874], "isController": false}, {"data": ["[POST] Demo Topup", 600, 315, 52.5, 62244.41833333332, 500, 200946, 62089.0, 101105.0, 101347.75, 181402.48000000004, 0.40354555121295704, 0.22601703567544446, 0.20222269211458543], "isController": false}, {"data": ["[POST] Generate QRIS CPM Transaksi", 600, 3, 0.5, 5016.808333333335, 73, 28548, 3838.0, 11590.299999999997, 14741.599999999982, 25312.840000000004, 0.5708843283688598, 7.409388206160128, 0.24752351419028146], "isController": false}, {"data": ["[POST] Demo QRIS CPM", 600, 62, 10.333333333333334, 4287.880000000006, 76, 26271, 2662.5, 10599.099999999999, 15113.699999999955, 22155.59000000002, 0.570486996224327, 0.5231246903919531, 0.3958728489668956], "isController": false}, {"data": ["[GET] Get Token Transaction History", 600, 95, 15.833333333333334, 46985.35333333337, 808, 181155, 30223.5, 100625.7, 101147.9, 178643.1700000005, 0.4040496550089362, 1.2793873258293458, 0.1801065805126178], "isController": false}, {"data": ["[GET] Account Mutation Summary", 600, 3, 0.5, 3778.971666666664, 70, 29882, 1858.0, 11019.199999999999, 13579.99999999997, 23041.280000000013, 0.5705309360891246, 0.6959075236508845, 0.23288415363399678], "isController": false}, {"data": ["[POST] Transfer QRIS", 600, 3, 0.5, 5210.138333333338, 70, 29353, 3988.5, 12147.999999999998, 15664.349999999997, 22876.740000000005, 0.5709006242798327, 0.6043992219457055, 0.38245045385410253], "isController": false}, {"data": ["[GET] List Transfer Destination", 600, 3, 0.5, 5107.816666666667, 71, 25042, 3769.5, 12605.699999999997, 16443.25, 20733.110000000004, 0.5709815744245933, 0.7959208065209903, 0.22024331755283008], "isController": false}, {"data": ["[POST] Forgot Username (Email)", 600, 0, 0.0, 2358.3333333333353, 72, 23242, 1665.0, 6038.2, 7777.099999999995, 12149.220000000001, 0.5709908118061867, 0.5358410486484171, 0.133825971517075], "isController": false}, {"data": ["[POST] Script Get QR-0", 600, 0, 0.0, 10582.86500000001, 249, 49534, 3256.0, 35180.4, 37438.349999999984, 46575.29, 0.5268801057975252, 0.5566423143779434, 2.1170178144200937], "isController": false}, {"data": ["[POST] Script Get QR-1", 600, 0, 0.0, 7173.418333333331, 218, 46185, 2263.5, 27084.1, 31199.44999999998, 41800.9, 0.5269888559423264, 0.3864807953184066, 0.19195208831410993], "isController": false}, {"data": ["[GET] User Profile", 600, 3, 0.5, 3124.07, 74, 31663, 1268.0, 9001.8, 12239.199999999979, 20820.820000000018, 0.5705320211096847, 0.6188359512432843, 0.21561263104407358], "isController": false}, {"data": ["[POST] Resend Verification OTP", 600, 234, 39.0, 5961.144999999996, 92, 36825, 4581.5, 13702.899999999998, 16002.05, 24996.870000000006, 0.5713757871891835, 0.5199352268171417, 0.2505265212999371], "isController": false}, {"data": ["[POST] Generate QRIS MPM Transaksi", 600, 3, 0.5, 4698.826666666658, 75, 30462, 3287.5, 11522.5, 14422.649999999983, 23910.760000000013, 0.5709218103549992, 6.577177225191544, 0.24698222476573176], "isController": false}, {"data": ["[POST] Verifikasi OTP", 600, 404, 67.33333333333333, 5228.888333333332, 75, 30450, 3548.5, 13069.299999999996, 15803.999999999985, 24717.210000000014, 0.5715390689819079, 0.503898573664718, 0.2505981141473066], "isController": false}, {"data": ["[POST] Forgot Password", 600, 1, 0.16666666666666666, 3881.7483333333344, 88, 23942, 3166.0, 7982.9, 10175.899999999992, 16856.46000000001, 0.5710886377156454, 0.5370120092207019, 0.12548334324806662], "isController": false}, {"data": ["[POST] Login with PIN", 600, 3, 0.5, 2900.186666666666, 74, 20421, 2149.0, 6469.3, 7998.099999999996, 11727.82, 0.5713115885794814, 0.6598788328461316, 0.24380052536861502], "isController": false}, {"data": ["[GET] Account Mutation Credit", 600, 3, 0.5, 3743.386666666665, 66, 34036, 1990.0, 10321.599999999999, 13436.149999999994, 20677.150000000012, 0.5704647576380477, 0.9501525072163793, 0.2612689593367967], "isController": false}, {"data": ["[POST] Demo Withdraw", 600, 338, 56.333333333333336, 64787.34166666666, 597, 163850, 81661.5, 101120.0, 101584.84999999999, 104066.79, 0.4583105451145623, 0.24923395898769896, 0.22340774203952776], "isController": false}, {"data": ["[GET] Account Mutation Debit", 600, 3, 0.5, 3876.2950000000014, 70, 34716, 2167.0, 9700.4, 13094.049999999977, 22485.5, 0.5704278779512513, 1.9496740227500897, 0.26069501021778935], "isController": false}, {"data": ["[POST] Forgot Username (Phone)", 600, 0, 0.0, 2544.9316666666687, 69, 18276, 1811.0, 6160.4, 7848.749999999995, 14422.890000000016, 0.5710016796966079, 0.5359553363675728, 0.1265794739171191], "isController": false}, {"data": ["[POST] Add Transfer Destination", 600, 3, 0.5, 4931.2416666666695, 75, 25236, 3556.0, 11676.0, 15311.099999999991, 21145.15000000001, 0.5710000494866709, 0.5983641859728128, 0.2531498608068421], "isController": false}, {"data": ["[POST] Verifikasi OTP Forgot Password", 600, 499, 83.16666666666667, 3999.823333333333, 73, 31226, 3005.0, 8710.8, 11078.249999999989, 17250.73, 0.5708941058038046, 0.5037146250819471, 0.19791739019565494], "isController": false}, {"data": ["[GET] Destination Detail", 600, 3, 0.5, 4991.633333333331, 69, 35596, 3269.5, 12271.5, 15715.199999999997, 22927.45000000001, 0.5709891816583049, 0.5833113586758951, 0.2407773277206683], "isController": false}, {"data": ["[GET] Account Detail", 600, 3, 0.5, 3450.7633333333315, 74, 23017, 1500.5, 10099.6, 13497.099999999964, 19731.000000000004, 0.5705401588954343, 0.6398667313278846, 0.21617287455961431], "isController": false}, {"data": ["[PATCH] Add to Favorites", 600, 3, 0.5, 4859.8233333333355, 78, 37063, 3541.0, 11304.099999999999, 14845.849999999973, 20991.280000000002, 0.5709918985766124, 0.583353166875713, 0.267543718648976], "isController": false}, {"data": ["[POST] Logout", 600, 3, 0.5, 4027.38333333333, 152, 29194, 2166.0, 9878.399999999998, 13533.049999999976, 18313.870000000006, 0.40462540791298934, 0.3714295285001278, 0.1604217248355029], "isController": false}, {"data": ["[POST] Script Get QR", 600, 0, 0.0, 17756.351666666676, 481, 83099, 5594.0, 57193.59999999999, 66329.34999999999, 78494.31, 0.5267709380473479, 0.9428479596405666, 2.3084518888030447], "isController": false}, {"data": ["[POST] Change User Profile", 600, 3, 0.5, 5589.951666666658, 79, 26330, 4317.0, 13473.199999999999, 16326.55, 22950.100000000002, 0.5644492903461297, 0.5229065942846688, 4.085934861493552], "isController": false}, {"data": ["[POST] Script Get QRIS-CPM", 600, 6, 1.0, 18589.776666666672, 483, 70979, 7053.5, 55075.6, 64289.149999999994, 67619.73, 0.5692226979448215, 0.5958549825722984, 7.0640444168028855], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["502/Bad Gateway", 4, 0.15606710885680844, 0.018518518518518517], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 3,272; received: 0)", 16, 0.6242684354272338, 0.07407407407407407], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,549; received: 0)", 1, 0.03901677721420211, 0.004629629629629629], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 172; received: 0)", 7, 0.2731174404994147, 0.032407407407407406], "isController": false}, {"data": ["400/Bad Request", 3, 0.11705033164260632, 0.013888888888888888], "isController": false}, {"data": ["503/Service Unavailable", 3, 0.11705033164260632, 0.013888888888888888], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,393; received: 0)", 1, 0.03901677721420211, 0.004629629629629629], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 175; received: 0)", 6, 0.23410066328521265, 0.027777777777777776], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,401; received: 0)", 1, 0.03901677721420211, 0.004629629629629629], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,477; received: 0)", 1, 0.03901677721420211, 0.004629629629629629], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,461; received: 0)", 1, 0.03901677721420211, 0.004629629629629629], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,529; received: 0)", 1, 0.03901677721420211, 0.004629629629629629], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 167; received: 0)", 4, 0.15606710885680844, 0.018518518518518517], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,465; received: 0)", 2, 0.07803355442840422, 0.009259259259259259], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,385; received: 0)", 1, 0.03901677721420211, 0.004629629629629629], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 45; received: 0)", 10, 0.3901677721420211, 0.046296296296296294], "isController": false}, {"data": ["400", 854, 33.3203277409286, 3.9537037037037037], "isController": false}, {"data": ["422", 9, 0.351150994927819, 0.041666666666666664], "isController": false}, {"data": ["500", 340, 13.265704252828716, 1.5740740740740742], "isController": false}, {"data": ["401", 54, 2.1069059695669137, 0.25], "isController": false}, {"data": ["500/Internal Server Error", 66, 2.575107296137339, 0.3055555555555556], "isController": false}, {"data": ["524", 808, 31.525555989075304, 3.740740740740741], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 161; received: 0)", 5, 0.19508388607101054, 0.023148148148148147], "isController": false}, {"data": ["401/Unauthorized", 364, 14.202106905969567, 1.6851851851851851], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 136; received: 0)", 1, 0.03901677721420211, 0.004629629629629629], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 21600, 2563, "400", 854, "524", 808, "401/Unauthorized", 364, "500", 340, "500/Internal Server Error", 66], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["[POST] Sign In", 600, 3, "500", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Generate QR", 600, 87, "524", 68, "500/Internal Server Error", 5, "401/Unauthorized", 3, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,465; received: 0)", 2, "502/Bad Gateway", 1], "isController": false}, {"data": ["[GET] Detail QRIS", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Transfer Intrabank", 600, 4, "401", 3, "502/Bad Gateway", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Generate Token Withdraw", 600, 205, "524", 187, "500/Internal Server Error", 8, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 175; received: 0)", 6, "401/Unauthorized", 2, "503/Service Unavailable", 1], "isController": false}, {"data": ["[GET] Mutation Detail", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Generate Token Topup", 600, 259, "524", 230, "500/Internal Server Error", 22, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 167; received: 0)", 4, "401/Unauthorized", 3, "", ""], "isController": false}, {"data": ["[POST] Demo Topup", 600, 315, "401/Unauthorized", 188, "524", 100, "500/Internal Server Error", 10, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 45; received: 0)", 8, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 161; received: 0)", 5], "isController": false}, {"data": ["[POST] Generate QRIS CPM Transaksi", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Demo QRIS CPM", 600, 62, "400", 56, "422", 6, "", "", "", "", "", ""], "isController": false}, {"data": ["[GET] Get Token Transaction History", 600, 95, "524", 61, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 3,272; received: 0)", 16, "500/Internal Server Error", 15, "401/Unauthorized", 3, "", ""], "isController": false}, {"data": ["[GET] Account Mutation Summary", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Transfer QRIS", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[GET] List Transfer Destination", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["[GET] User Profile", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Resend Verification OTP", 600, 234, "400", 234, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Generate QRIS MPM Transaksi", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Verifikasi OTP", 600, 404, "400", 291, "500", 110, "401", 3, "", "", "", ""], "isController": false}, {"data": ["[POST] Forgot Password", 600, 1, "500", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Login with PIN", 600, 3, "422", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[GET] Account Mutation Credit", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Demo Withdraw", 600, 338, "401/Unauthorized", 165, "524", 162, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 172; received: 0)", 7, "500/Internal Server Error", 3, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 45; received: 0)", 1], "isController": false}, {"data": ["[GET] Account Mutation Debit", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["[POST] Add Transfer Destination", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Verifikasi OTP Forgot Password", 600, 499, "400", 273, "500", 226, "", "", "", "", "", ""], "isController": false}, {"data": ["[GET] Destination Detail", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[GET] Account Detail", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[PATCH] Add to Favorites", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Logout", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["[POST] Change User Profile", 600, 3, "401", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Script Get QRIS-CPM", 600, 6, "400/Bad Request", 3, "500/Internal Server Error", 3, "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
